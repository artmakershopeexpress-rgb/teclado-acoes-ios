# Teclado Ações — iOS

Projeto nativo iOS (Swift + UIKit/SwiftUI) com um teclado QWERTY simples, Shift, números,
tecla 🌐 e botão **⋯ Ações** com **Selecionar tudo / Copiar / Colar**.

## Como abrir e instalar

1. Em um **Mac com Xcode**, abra `TecladoAcoes.xcodeproj`.
2. Selecione o target **TecladoAcoes** e escolha seu Team em **Signing & Capabilities**.
3. Faça o mesmo no target **TecladoAcoesKeyboard**. Se necessário, substitua os IDs
   `com.exemplo.tecladoacoes` e `com.exemplo.tecladoacoes.keyboard` por IDs únicos,
   mantendo o segundo como subidentificador do primeiro.
4. Conecte o iPhone e execute o aplicativo com o Xcode.
5. No iPhone, vá a **Ajustes > Geral > Teclado > Teclados > Adicionar Novo Teclado**
   e escolha **Teclado Ações**.
6. Para usar copiar/colar, nas opções do teclado ative **Permitir Acesso Total**.
7. Abra um campo de texto e use a tecla 🌐 para ativar o teclado.

## Funcionalidades

- Digitação QWERTY básica, letras maiúsculas com Shift, toque duplo para Caps Lock.
- Números e pontuação básicos, espaço, retorno, apagar, tecla 🌐.
- **Copiar**: copia o texto que a pessoa já selecionou no aplicativo hospedeiro.
- **Colar**: insere o texto da área de transferência no campo atual. A partir do iOS 16,
  o sistema pode apresentar uma confirmação de permissão para colar.
- **Selecionar tudo**: o item informa a limitação; não consegue selecionar remotamente
  o texto de aplicativos como WhatsApp, Safari ou Notas. O próprio app que edita o texto
  deve disponibilizar essa função.

## Limitações importantes

- A API pública de teclado de terceiros (`UITextDocumentProxy`) não oferece seleção
  programática universal nem acionamento do menu de edição de outro app.
- `selectedText` pode não conter uma seleção muito extensa; faça testes com textos longos.
- O iOS substitui teclados de terceiros em campos protegidos (senhas) e certos campos telefônicos.
- Este é um **protótipo-fonte**, ainda **não compilado ou testado em dispositivo real**.
- Esta versão básica não inclui autocorreção, ditado, emojis ou acentos long-press.
- O teclado tem o atributo `RequestsOpenAccess` ativado para permitir acesso ao clipboard;
  o usuário também deve ativar **Permitir Acesso Total**. Não há código de rede, telemetria
  ou armazenamento de textos.

## Fontes Apple

- https://developer.apple.com/documentation/uikit/creating-a-custom-keyboard
- https://developer.apple.com/documentation/uikit/uitextdocumentproxy
- https://developer.apple.com/documentation/uikit/configuring-open-access-for-a-custom-keyboard
- https://developer.apple.com/documentation/uikit/uipasteboard


## Alternativa gratuita sem Mac — GitHub Actions + Windows/Sideloadly

Este ZIP inclui `.github/workflows/compilar-iphone.yml` e um esquema Xcode compartilhado.

### Parte A — Compilar na nuvem

1. Acesse `https://github.com` e crie uma conta gratuita (ou entre na sua).
2. Crie um repositório **público** chamado `teclado-acoes-ios` (GitHub Actions em
   runners macOS padrão é gratuito para repositórios públicos).
3. Descompacte este ZIP e envie para a raiz do repositório o conteúdo da pasta
   `TecladoAcoes_iOS` — *incluindo a pasta oculta `.github`*.
   Não envie apenas o ZIP como arquivo, pois o GitHub não compila arquivos zipados automaticamente.
4. Em seu repositório, abra **Actions** → **Compilar teclado iPhone (IPA sem assinatura)**
   → **Run workflow**. Alternativamente, o workflow executa a cada push na branch `main`.
5. Depois que a execução aparecer como concluída, abra a execução e, em **Artifacts**,
   baixe **TecladoAcoes-IPA-para-Sideloadly**. Descompacte o ZIP de artifact para obter
   `TecladoAcoes-sem-assinatura.ipa`.

### Parte B — Instalar no iPhone sem Mac

1. Em um **computador Windows** (não precisa ser Mac), instale o Sideloadly oficial
   em `https://sideloadly.io/`. Siga o site para configurar o iTunes e iCloud
   para Windows quando exigidos.
2. Conecte o iPhone por USB e autorize o computador.
3. Selecione `TecladoAcoes-sem-assinatura.ipa` no Sideloadly e use sua conta Apple
   para assinar e instalar. Preserve a extensão `TecladoAcoesKeyboard.appex`;
   não escolha configurações que removam extensões/PlugIns.
4. Caso o iOS solicite, ative **Modo de Desenvolvedor** em
   Ajustes → Privacidade e Segurança, confirme e reinicie o aparelho.
5. Abra o aplicativo **Teclado Ações** e siga as instruções para habilitar o teclado
   em Ajustes → Geral → Teclado → Teclados.
6. A assinatura gratuita dura **7 dias**; use a renovação automática do Sideloadly
   (com Windows ligado conforme necessidade) ou instale novamente.

### Ressalvas

- O arquivo `.ipa` do GitHub é deliberadamente **não assinado** e não pode ser instalado
  com um toque pelo Safari, Archivos ou pelo próprio GitHub.
- Apenas com um iPhone, sem Mac **nem Windows** e sem assinatura/serviço de distribuição,
  não existe neste fluxo uma instalação confiável 100% on-line e gratuita.
- Sideloadly é um programa de terceiros. Faça download somente do site oficial;
  nunca compartilhe sua senha Apple comigo, no GitHub ou em arquivos do repositório.
- Com conta gratuita podem ocorrer limites do número de apps/identificadores registrados.
- O fluxo foi preparado mas ainda **não executado em um runner macOS** ou testado no iPhone.

Fontes úteis:
- https://docs.github.com/en/actions/how-tos/write-workflows/choose-where-workflows-run/choose-the-runner-for-a-job
- https://sideloadly.io/
- https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device
