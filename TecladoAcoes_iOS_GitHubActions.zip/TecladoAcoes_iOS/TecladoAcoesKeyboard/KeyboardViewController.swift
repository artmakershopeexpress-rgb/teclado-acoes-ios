import UIKit

/// Extensão de teclado minimalista. Não utiliza rede nem armazena o texto digitado.
final class KeyboardViewController: UIInputViewController {
    private var shiftEnabled = true
    private var capsLockEnabled = false
    private var numbersEnabled = false
    private var actionsVisible = false
    private var lastShiftTap: Date?
    private var statusMessage = ""

    private var heightConstraint: NSLayoutConstraint?
    private let columnStack = UIStackView()

    private let keyBackground = UIColor { traits in
        traits.userInterfaceStyle == .dark ? UIColor(white: 0.31, alpha: 1) : .white
    }
    private let specialBackground = UIColor { traits in
        traits.userInterfaceStyle == .dark ? UIColor(white: 0.22, alpha: 1) : UIColor(red: 0.70, green: 0.73, blue: 0.79, alpha: 1)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor { traits in
            traits.userInterfaceStyle == .dark ? UIColor(white: 0.14, alpha: 1) : UIColor(red: 0.82, green: 0.85, blue: 0.89, alpha: 1)
        }

        columnStack.axis = .vertical
        columnStack.alignment = .fill
        columnStack.distribution = .fill
        columnStack.spacing = 6
        columnStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(columnStack)

        NSLayoutConstraint.activate([
            columnStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            columnStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            columnStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 7),
            columnStack.bottomAnchor.constraint(lessThanOrEqualTo: view.bottomAnchor, constant: -6)
        ])
        let fixedHeight = view.heightAnchor.constraint(equalToConstant: 269)
        fixedHeight.priority = .defaultHigh
        fixedHeight.isActive = true
        heightConstraint = fixedHeight
        renderKeyboard()
    }

    override func textDidChange(_ textInput: UITextInput?) {
        super.textDidChange(textInput)
        // A seleção e o conteúdo do campo são controlados pelo aplicativo hospedeiro.
    }

    private func renderKeyboard() {
        for subview in columnStack.arrangedSubviews {
            columnStack.removeArrangedSubview(subview)
            subview.removeFromSuperview()
        }

        let toolbar = UIStackView()
        toolbar.axis = .horizontal
        toolbar.spacing = 6
        toolbar.distribution = .fill

        let status = UILabel()
        status.text = statusMessage.isEmpty ? "Teclado Ações" : statusMessage
        status.font = .systemFont(ofSize: statusMessage.isEmpty ? 12 : 11, weight: .medium)
        status.textColor = .label
        status.minimumScaleFactor = 0.7
        status.adjustsFontSizeToFitWidth = true
        status.numberOfLines = 2
        toolbar.addArrangedSubview(status)

        let actions = makeKey(actionsVisible ? "Fechar ✕" : "⋯ Ações", identifier: "actions", special: true)
        actions.widthAnchor.constraint(equalToConstant: 105).isActive = true
        toolbar.addArrangedSubview(actions)
        columnStack.addArrangedSubview(toolbar)
        toolbar.heightAnchor.constraint(equalToConstant: 35).isActive = true

        if actionsVisible {
            let actionRow = makeRow([
                ("Selecionar tudo", "selectAll", 1.45),
                ("Copiar", "copy", 1.0),
                ("Colar", "paste", 1.0)
            ])
            columnStack.addArrangedSubview(actionRow)
            actionRow.heightAnchor.constraint(equalToConstant: 39).isActive = true
        }

        let firstRow = numbersEnabled ? Array("1234567890").map(String.init) : Array("qwertyuiop").map(String.init)
        let secondRow = numbersEnabled ? ["@", "#", "$", "%", "&", "-", "+", "(", ")"] : Array("asdfghjklç").map(String.init)
        let thirdRow = numbersEnabled ? ["*", "\"", ":", ";", "!", "?", "/", "."] : Array("zxcvbnm").map(String.init)

        columnStack.addArrangedSubview(makeLettersRow(firstRow))
        columnStack.addArrangedSubview(makeLettersRow(secondRow, inset: 12))

        let third = UIStackView()
        third.axis = .horizontal
        third.distribution = .fill
        third.spacing = 4
        let shiftTitle = numbersEnabled ? "#+=" : (capsLockEnabled ? "⇪" : "⇧")
        let shiftButton = makeKey(shiftTitle, identifier: "shift", special: true, active: shiftEnabled || capsLockEnabled)
        shiftButton.widthAnchor.constraint(equalToConstant: 47).isActive = true
        third.addArrangedSubview(shiftButton)
        for char in thirdRow {
            third.addArrangedSubview(makeKey(display(char), identifier: "type:" + char))
        }
        let back = makeKey("⌫", identifier: "backspace", special: true)
        back.widthAnchor.constraint(equalToConstant: 47).isActive = true
        third.addArrangedSubview(back)
        columnStack.addArrangedSubview(third)

        let bottom = UIStackView()
        bottom.axis = .horizontal
        bottom.distribution = .fill
        bottom.spacing = 4
        let mode = makeKey(numbersEnabled ? "ABC" : "123", identifier: "numbers", special: true)
        mode.widthAnchor.constraint(equalToConstant: 48).isActive = true
        bottom.addArrangedSubview(mode)

        let globe = makeKey("🌐", identifier: "globe", special: true)
        globe.widthAnchor.constraint(equalToConstant: 39).isActive = true
        // O sistema decide se mostra a lista de teclados ou alterna diretamente.
        globe.removeTarget(self, action: #selector(keyPressed(_:)), for: .touchUpInside)
        globe.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
        bottom.addArrangedSubview(globe)

        let space = makeKey("espaço", identifier: "space")
        bottom.addArrangedSubview(space)
        let enter = makeKey("↵", identifier: "enter", special: true)
        enter.widthAnchor.constraint(equalToConstant: 55).isActive = true
        bottom.addArrangedSubview(enter)
        columnStack.addArrangedSubview(bottom)

        for row in columnStack.arrangedSubviews.dropFirst(actionsVisible ? 2 : 1) {
            row.heightAnchor.constraint(equalToConstant: 46).isActive = true
        }
        heightConstraint?.constant = actionsVisible ? 315 : 269
    }

    private func makeLettersRow(_ letters: [String], inset: CGFloat = 0) -> UIStackView {
        let row = UIStackView()
        row.axis = .horizontal
        row.spacing = 4
        row.distribution = .fillEqually
        if inset > 0 {
            let leading = UIView()
            let trailing = UIView()
            leading.widthAnchor.constraint(equalToConstant: inset).isActive = true
            trailing.widthAnchor.constraint(equalToConstant: inset).isActive = true
            row.addArrangedSubview(leading)
            for letter in letters { row.addArrangedSubview(makeKey(display(letter), identifier: "type:" + letter)) }
            row.addArrangedSubview(trailing)
            row.distribution = .fill
            for button in row.arrangedSubviews.compactMap({ $0 as? UIButton }) {
                button.widthAnchor.constraint(greaterThanOrEqualToConstant: 20).isActive = true
            }
            // O espaço restante é dividido igualmente pelas teclas via uma largura relativa.
            if let first = row.arrangedSubviews.compactMap({ $0 as? UIButton }).first {
                for button in row.arrangedSubviews.compactMap({ $0 as? UIButton }).dropFirst() {
                    button.widthAnchor.constraint(equalTo: first.widthAnchor).isActive = true
                }
            }
        } else {
            for letter in letters { row.addArrangedSubview(makeKey(display(letter), identifier: "type:" + letter)) }
        }
        return row
    }

    private func makeRow(_ items: [(String, String, CGFloat)]) -> UIStackView {
        let row = UIStackView()
        row.axis = .horizontal
        row.distribution = .fillProportionally
        row.spacing = 5
        for (name, id, _) in items {
            let button = makeKey(name, identifier: id, special: true)
            button.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
            row.addArrangedSubview(button)
        }
        if items.count > 1, let first = row.arrangedSubviews.first {
            for (i, entry) in items.enumerated().dropFirst() {
                row.arrangedSubviews[i].widthAnchor.constraint(equalTo: first.widthAnchor, multiplier: entry.2 / items[0].2).isActive = true
            }
        }
        return row
    }

    private func makeKey(_ label: String, identifier: String, special: Bool = false, active: Bool = false) -> UIButton {
        let button = UIButton(type: .system)
        button.accessibilityIdentifier = identifier
        button.accessibilityLabel = label
        button.setTitle(label, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: label.count > 1 ? 15 : 21, weight: .regular)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.65
        button.setTitleColor(active ? .white : .label, for: .normal)
        button.backgroundColor = active ? .systemIndigo : (special ? specialBackground : keyBackground)
        button.layer.cornerRadius = 5
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.12
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        button.layer.shadowRadius = 0.5
        button.addTarget(self, action: #selector(keyPressed(_:)), for: .touchUpInside)
        return button
    }

    private func display(_ character: String) -> String {
        numbersEnabled ? character : ((shiftEnabled || capsLockEnabled) ? character.uppercased() : character)
    }

    @objc private func keyPressed(_ sender: UIButton) {
        guard let id = sender.accessibilityIdentifier else { return }
        statusMessage = ""
        switch id {
        case "actions":
            actionsVisible.toggle()
        case "shift":
            if numbersEnabled {
                numbersEnabled = false
                shiftEnabled = false
                capsLockEnabled = false
            } else {
                let now = Date()
                if let previous = lastShiftTap, now.timeIntervalSince(previous) < 0.45 {
                    capsLockEnabled = true
                    shiftEnabled = true
                    lastShiftTap = nil
                } else if capsLockEnabled {
                    capsLockEnabled = false
                    shiftEnabled = false
                    lastShiftTap = now
                } else {
                    shiftEnabled.toggle()
                    lastShiftTap = now
                }
            }
        case "backspace":
            textDocumentProxy.deleteBackward()
        case "numbers":
            numbersEnabled.toggle()
        case "space":
            textDocumentProxy.insertText(" ")
        case "enter":
            textDocumentProxy.insertText("\n")
        case "copy":
            copySelectedText()
        case "paste":
            pasteClipboardText()
        case "selectAll":
            statusMessage = "Selecione tudo pelo app (limitação do iOS)."
        default:
            if id.hasPrefix("type:") {
                let value = String(id.dropFirst(5))
                textDocumentProxy.insertText(display(value))
                if shiftEnabled && !capsLockEnabled && !numbersEnabled {
                    shiftEnabled = false
                }
            }
        }
        renderKeyboard()
    }

    private func copySelectedText() {
        guard hasFullAccess else {
            statusMessage = "Ative Permitir Acesso Total em Ajustes."
            return
        }
        guard let selected = textDocumentProxy.selectedText, !selected.isEmpty else {
            statusMessage = "Selecione um texto antes de copiar."
            return
        }
        UIPasteboard.general.string = selected
        statusMessage = "Texto selecionado copiado."
    }

    private func pasteClipboardText() {
        guard hasFullAccess else {
            statusMessage = "Ative Permitir Acesso Total em Ajustes."
            return
        }
        // O iOS pode pedir a permissão de colagem da área de transferência.
        guard let clipboard = UIPasteboard.general.string, !clipboard.isEmpty else {
            statusMessage = "Nada disponível para colar."
            return
        }
        textDocumentProxy.insertText(clipboard)
        statusMessage = "Texto colado."
    }
}
