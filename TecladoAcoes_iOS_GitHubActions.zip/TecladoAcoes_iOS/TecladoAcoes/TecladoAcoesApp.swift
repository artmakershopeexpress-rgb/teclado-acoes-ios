import SwiftUI

@main
struct TecladoAcoesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var testText = "Digite aqui para experimentar o teclado."

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Label("Teclado Ações", systemImage: "keyboard")
                        .font(.largeTitle.bold())

                    Text("Um teclado simples para iPhone com Shift e um menu Ações.")
                        .foregroundStyle(.secondary)

                    GroupBox("Como ativar") {
                        VStack(alignment: .leading, spacing: 9) {
                            Text("1. Abra Ajustes > Geral > Teclado > Teclados.")
                            Text("2. Toque em Adicionar Novo Teclado e escolha Teclado Ações.")
                            Text("3. Para Copiar e Colar, ative Permitir Acesso Total nas opções do teclado.")
                            Text("4. Use a tecla 🌐 para trocar de teclado enquanto digita.")
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Text("Área de teste")
                        .font(.headline)

                    TextEditor(text: $testText)
                        .font(.body)
                        .frame(minHeight: 150)
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .background(Color(.secondarySystemGroupedBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(.gray.opacity(0.25)))

                    GroupBox("O que funciona") {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("• Shift e digitação normal.")
                            Text("• Copiar texto selecionado manualmente.")
                            Text("• Colar texto da área de transferência.")
                            Text("• Selecionar tudo: disponível pelo menu de edição do próprio aplicativo, não pelo teclado em outros apps.")
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Text("Privacidade: este projeto não possui conexão com servidores, rastreamento, análise de digitação ou armazenamento de textos. O iOS pode solicitar permissão para colar conteúdo de outro aplicativo.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(20)
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
